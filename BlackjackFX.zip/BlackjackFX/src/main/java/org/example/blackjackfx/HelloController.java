package org.example.blackjackfx;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextInputDialog;

import java.util.Optional;

public class HelloController {
    @FXML
    private Label playerHandLabel;

    @FXML
    private Label dealerHandLabel;

    @FXML
    private Label playerTotalLabel;

    @FXML
    private Label dealerTotalLabel;

    @FXML
    private Label resultLabel;

    @FXML
    private Label chipsLabel;

    @FXML
    private Button dealButton;

    @FXML
    private Button hitButton;

    @FXML
    private Button standButton;

    @FXML
    private Button betButton;

    private BlackjackGame game;

    @FXML
    protected void initialize() {
        game = new BlackjackGame(playerHandLabel, dealerHandLabel, playerTotalLabel, dealerTotalLabel, resultLabel,
                dealButton, hitButton, standButton, betButton, betSlider, chipsLabel);

        betSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            betButton.setText("Bet: " + (int) newValue.doubleValue());
        });

        game.updateMaxBet();
    }

    @FXML
    protected void onDealButtonClick() {
        game.startNewRound();
    }

    @FXML
    protected void onHitButtonClick() {
        game.playerHits();
    }
    @FXML
    private void resetChips() {
        game.resetChips();
    }
    @FXML
    protected void onStandButtonClick() {
        game.playerStands();
    }
    @FXML
    private Slider betSlider;

    @FXML
    private void onBetButtonClick() {
        int bet = (int) betSlider.getValue();
        game.placeBet(bet);
    }
    private void showErrorDialog(String title, String message) {
        // Display an error dialog with the specified title and message
        TextInputDialog errorDialog = new TextInputDialog();
        errorDialog.setTitle(title);
        errorDialog.setHeaderText(null);
        errorDialog.setContentText(message);
        errorDialog.showAndWait();
    }
}
