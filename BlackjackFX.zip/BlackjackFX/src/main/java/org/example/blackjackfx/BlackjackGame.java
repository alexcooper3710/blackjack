package org.example.blackjackfx;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;

public class BlackjackGame {
    private Card card;
    private int chips;
    private Slider betSlider;
    private int currentBet;

    private Label playerHandLabel;
    private Label dealerHandLabel;
    private Label playerTotalLabel;
    private Label dealerTotalLabel;
    private Label resultLabel;
    private Label chipsLabel;
    private Button dealButton;
    private Button hitButton;
    private Button standButton;
    private Button betButton;

    public BlackjackGame(Label playerHandLabel, Label dealerHandLabel, Label playerTotalLabel, Label dealerTotalLabel,
                         Label resultLabel, Button dealButton, Button hitButton, Button standButton, Button betButton,
                         Slider betSlider, Label chipsLabel) {
        this.card = new Card();
        this.chips = 2500;
        this.betSlider = betSlider;

        this.playerHandLabel = playerHandLabel;
        this.dealerHandLabel = dealerHandLabel;
        this.playerTotalLabel = playerTotalLabel;
        this.dealerTotalLabel = dealerTotalLabel;
        this.resultLabel = resultLabel;
        this.chipsLabel = chipsLabel;
        this.dealButton = dealButton;
        this.hitButton = hitButton;
        this.standButton = standButton;
        this.betButton = betButton;

        dealButton.setOnAction(event -> startNewRound());
        hitButton.setOnAction(event -> playerHits());
        standButton.setOnAction(event -> playerStands());

        updateChipsLabel();
    }

    public void updateMaxBet() {
        betSlider.setMax(chips);
        betSlider.setValue(0);
    }

    public void startNewRound() {
        playerHandLabel.setText("");
        dealerHandLabel.setText("");
        playerTotalLabel.setText("");
        dealerTotalLabel.setText("");
        resultLabel.setText("");
        updateMaxBet();
        dealButton.setDisable(true);
        hitButton.setDisable(false);
        standButton.setDisable(false);
        betButton.setDisable(false);
        betSlider.setDisable(false);
        card.newDeck();
        card.shuffleDeck();
        dealInitialCards();
    }

    public void playerHits() {
        playerHandLabel.setText(playerHandLabel.getText() + ", " + card.pickCard());
        int playerTotal = calculateTotal(playerHandLabel.getText());
        playerTotalLabel.setText("Player Total: " + playerTotal);

        if (playerTotal > 21) {
            endRound("You Bust! Better luck next time!");
        }
    }

    public void playerStands() {
        String dealerHand = dealerHandLabel.getText().replace("?", card.pickCard());
        dealerHandLabel.setText(dealerHand);

        int playerTotal = calculateTotal(playerHandLabel.getText());
        int dealerTotal = calculateTotal(dealerHandLabel.getText());
        playerTotalLabel.setText("Player Total: " + playerTotal);
        dealerTotalLabel.setText("Dealer Total: " + dealerTotal);

        while (dealerTotal < 17) {
            dealerHand = dealerHandLabel.getText() + ", " + card.pickCard();
            dealerHandLabel.setText(dealerHand);
            dealerTotal = calculateTotal(dealerHand);
            dealerTotalLabel.setText("Dealer Total: " + dealerTotal);
        }

        if (dealerTotal > 21 || playerTotal > dealerTotal) {
            endRound("You Win!");
        } else if (playerTotal < dealerTotal) {
            endRound("You Lose! Better luck next time!");
        } else {
            endRound("It's a tie!");
        }
    }

    public void placeBet(int bet) {
        chips -= bet;
        updateChipsLabel();
        betButton.setText("Bet: " + bet);
        betButton.setDisable(true);
        betSlider.setDisable(false);
        dealButton.setDisable(false);
        hitButton.setDisable(true);
        standButton.setDisable(true);

        currentBet = bet;
    }

    private void dealInitialCards() {
        playerHandLabel.setText(playerHandLabel.getText() + card.pickCard() + ", " + card.pickCard());
        dealerHandLabel.setText(dealerHandLabel.getText() + card.dCard() + ", ?");
    }

    private void endRound(String message) {
        resultLabel.setText(message);
        betButton.setDisable(false);
        betSlider.setValue(0);
        betSlider.setDisable(false);
        dealButton.setDisable(false);
        hitButton.setDisable(true);
        standButton.setDisable(true);
        updateChipsLabel();
        updateMaxBet();
        if (message.equals("You Win!")) {
            chips += 2 * currentBet;
            updateChipsLabel();
            updateMaxBet();
            betSlider.setDisable(false);
        }
        if (message.equals("It's a tie!")) {
            chips += currentBet;
            updateChipsLabel();
            updateMaxBet();
            betSlider.setDisable(false);
        }
    }

    public int calculateTotal(String hand) {
        int total = 0;
        int numAces = 0;

        String[] cards = hand.split(", ");
        for (String card : cards) {
            String cardRank = card.trim();

            switch (cardRank) {
                case "2":
                case "3":
                case "4":
                case "5":
                case "6":
                case "7":
                case "8":
                case "9":
                    total += Integer.parseInt(cardRank);
                    break;
                case "10":
                case "Jack":
                case "Queen":
                case "King":
                    total += 10;
                    break;
                case "Ace":
                    numAces++;
                    total += 11;
                    break;
            }
        }

        while (total > 21 && numAces > 0) {
            total -= 10;
            numAces--;
        }

        return total;
    }
    public void resetChips() {
        chips = 2500;
        updateChipsLabel();
        updateMaxBet();
        betSlider.setDisable(false);
    }

    private void updateChipsLabel() {
        chipsLabel.setText(Integer.toString(chips));
    }
}
