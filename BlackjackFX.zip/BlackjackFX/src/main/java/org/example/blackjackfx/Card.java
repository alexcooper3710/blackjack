package org.example.blackjackfx;

import java.util.ArrayList;
import java.util.Collections;

public class Card {
    private ArrayList<String> deck = new ArrayList<>();
    private final String[] cards = {
            "2, Hearts", "3, Hearts", "4, Hearts", "5, Hearts", "6, Hearts", "7, Hearts", "8, Hearts", "9, Hearts", "10, Hearts", "Jack, Hearts", "Queen, Hearts", "King, Hearts", "Ace, Hearts",
            "2, Diamonds", "3, Diamonds", "4, Diamonds", "5, Diamonds", "6, Diamonds", "7, Diamonds", "8, Diamonds", "9, Diamonds", "10, Diamonds", "Jack, Diamonds", "Queen, Diamonds", "King, Diamonds", "Ace, Diamonds",
            "2, Clubs", "3, Clubs", "4, Clubs", "5, Clubs", "6, Clubs", "7, Clubs", "8, Clubs", "9, Clubs", "10, Clubs", "Jack, Clubs", "Queen, Clubs", "King, Clubs", "Ace, Clubs",
            "2, Spades", "3, Spades", "4, Spades", "5, Spades", "6, Spades", "7, Spades", "8, Spades", "9, Spades", "10, Spades", "Jack, Spades", "Queen, Spades", "King, Spades", "Ace, Spades"
    };

    public void newDeck() {
        deck.clear();
        Collections.addAll(deck, cards);
    }

    public void shuffleDeck() {
        Collections.shuffle(deck);
    }

    public String pickCard() {
        int index = (int) (Math.random() * deck.size());
        String newCard = deck.get(index);
        deck.remove(index);
        return newCard;
    }

    public String dCard() {
        return pickCard();
    }
}
